<?php 
  $conn = new mysqli('localhost', 'root', '', 'wsb_nst');
  // echo "string";
 ?>