<?php 
  $conn = new mysqli("localhost", "root", "", "wsb_php_gr_2");
  // echo "plik z połączeniem db";
  // echo $conn->connect_errno;
 ?>